// itemlines_server.c
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <microhttpd.h>

#define PORT 5051

// --- DATA ---
static const char *itemlines[] = {
    "101 18V Cordless Drill 2 89.99",
    "102 6-inch Wood Clamp 4 12.50",
    "103 Carpenter's Hammer 1 19.99"
};
static const int itemline_count = 3;

// HTTP handler callback
static int ahc_handler(void *cls, struct MHD_Connection *connection,
                       const char *url, const char *method,
                       const char *version, const char *upload_data,
                       size_t *upload_data_size, void **ptr) {
    (void)cls; (void)version; (void)upload_data; (void)upload_data_size;

    if (strcmp(method, "GET") != 0) {
        return MHD_NO; // Only GET supported
    }

    struct MHD_Response *response;
    int ret;

    if (strcmp(url, "/itemlines") == 0) {
        // Build response buffer
        size_t buffer_size = 0;
        for (int i = 0; i < itemline_count; i++) {
            buffer_size += strlen(itemlines[i]) + 20; // <custom> + </custom> + newline
        }
        char *buffer = malloc(buffer_size + 1);
        if (!buffer) return MHD_NO;

        buffer[0] = '\0';
        for (int i = 0; i < itemline_count; i++) {
            strcat(buffer, "<custom>");
            strcat(buffer, itemlines[i]);
            strcat(buffer, "</custom>\n");
        }

        response = MHD_create_response_from_buffer(strlen(buffer), (void *)buffer,
                                                   MHD_RESPMEM_MUST_FREE);
        MHD_add_response_header(response, "Content-Type", "text/plain");
        ret = MHD_queue_response(connection, MHD_HTTP_OK, response);
        MHD_destroy_response(response);
    } else {
        const char *not_found = "Not Found";
        response = MHD_create_response_from_buffer(strlen(not_found),
                                                   (void *)not_found,
                                                   MHD_RESPMEM_PERSISTENT);
        ret = MHD_queue_response(connection, MHD_HTTP_NOT_FOUND, response);
        MHD_destroy_response(response);
    }
    return ret;
}

// Start server (for EXE or library)
int start_itemlines_server() {
    struct MHD_Daemon *daemon;
    daemon = MHD_start_daemon(MHD_USE_SELECT_INTERNALLY, PORT, NULL, NULL,
                              &ahc_handler, NULL, MHD_OPTION_END);
    if (daemon == NULL) {
        fprintf(stderr, "Failed to start server\n");
        return 1;
    }
    printf("[A] Legacy server at http://0.0.0.0:%d/itemlines\n", PORT);
    getchar(); // Keep running until user presses Enter
    MHD_stop_daemon(daemon);
    return 0;
}

// Only include main() when building as EXE
#ifdef BUILD_EXE
int main() {
    return start_itemlines_server();
}
#endif
