Found this very Useful.

Making Simple Windows Driver in C

https://www.youtube.com/watch?v=GTrekHE8A00