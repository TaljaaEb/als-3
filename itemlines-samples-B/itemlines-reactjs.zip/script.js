import http from 'http';

// --- DATA ---
const itemlines = [
    "101 18V Cordless Drill 2 89.99",
    "102 6-inch Wood Clamp 4 12.50",
    "103 Carpenter's Hammer 1 19.99"
];

const requestHandler = (req, res) => {
    if (req.url === "/itemlines") {
        res.writeHead(200, { "Content-Type": "text/plain" });
        itemlines.forEach(item => {
            res.write(`<custom>${item}</custom>\n`);
        });
        res.end();
    } else {
        res.writeHead(404);
        res.end("Not Found");
    }
};

// -------------------------
// Runner
// -------------------------
const runHttpServer = (host = "0.0.0.0", port = 5051) => {
    const server = http.createServer(requestHandler);
    server.listen(port, host, () => {
        console.log(`[A] Legacy server at http://${host}:${port}/itemlines`);
    });
};

// Start legacy HTTP server
runHttpServer();